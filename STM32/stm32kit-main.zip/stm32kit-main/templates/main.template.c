/**
 * @file   <nazev>.c
 * @author <Jmeno Prijmeni>
 * 
 */

#include "stm32_kit.h"

BOARD_SETUP void setup(void) {
	//TODO
};

int main(void) {
	while (1) {
		//TODO
	}
}

