/* Zacnete volbou sablony v "templates" nebo "examples" */
