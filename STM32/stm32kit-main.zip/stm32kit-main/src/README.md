# Složka SRC

Složka SRC slouží pro zdrojové kódy aplikace. Zde patří vaše programy.